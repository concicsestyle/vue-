import axios from 'axios';

var server = axios.create({
    baseURL:"/",
    timeout:6000,//6秒
    headers:{//所有的都会携带这个请求
        'classes':2020
    }
}) 


export default server