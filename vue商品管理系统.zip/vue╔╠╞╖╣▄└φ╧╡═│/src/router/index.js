import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Login from '../views/Login.vue'
import NoFound from '../views/404.vue'
import Echarts from '../views/Echarts.vue'
import Category from '../views/Category.vue'
import Product from '../views/Product.vue'
import Role from '../views/Role.vue'
import User from '../views/User.vue'
import Order from '../views/Order.vue'
import Productdata from '../views/Productdata.vue'
import Productadd from '../views/Productadd.vue'
import Productup from '../views/Productup.vue'



Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'login',
    component: Login
  },
  {
    path: '/home',
    name: 'home',
    redirect:'/home/echarts',
    component: Home,
    children:[{
      path: 'echarts',
      component:Echarts
    },
    {
      path: 'category',
      component:Category
    },
    {
      path: 'echarts',
      component:Echarts
    },
    {
      path: 'product',
      component:Product
    },
    {
      path: 'productdata',
      component:Productdata
    },
    {
      path: 'productadd',
      component:Productadd
    },
    {
      path: 'productup',
      component:Productup
    },
    {
      path: 'user',
      component:User
    },
    {
      path: 'role',
      component:Role
    },
    {
      path: 'order',
      component:Order
    }
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path:'*',
    component:NoFound,
  }
]

const router = new VueRouter({
  routes
})

export default router
