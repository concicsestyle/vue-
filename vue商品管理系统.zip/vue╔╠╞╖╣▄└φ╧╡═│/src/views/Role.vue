<template>

<el-card class="box-card">
  <div slot="header" class="clearfix">
    <el-button style="float:left;" @click="open" type="primary">创建角色</el-button>
  </div>
  <el-table
    :data="tableData"
    :row-class-name="tableRowClassName"
    border
    style="width: 100%">
    <el-table-column
      prop="name"
      label="角色名称">
    </el-table-column>
    <el-table-column>
      <template slot-scope="scope">
        <span>{{timestampToTime(scope.row.create_time)}}</span>
      </template>
    </el-table-column>
    <el-table-column
      label="授权时间">
      <template slot-scope="scope">
        <span>{{timestampToTime(scope.row.auth_time)}}</span>
      </template>
    </el-table-column>
    <el-table-column
      prop="auth_name"
      label="授权人">
    </el-table-column>
    <el-table-column
      label="操作">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="handleEdit(scope.row)">设置权限</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-pagination
    background
    @current-change="handleCurrentChange"
    layout="prev, pager, next"
    :page-size='obj.pageSize'
    :total="total">
  </el-pagination>
  <el-dialog style="float:left" title="设置权限" :visible.sync="dialogFormVisible">
    <el-tree
        :data="data"
        show-checkbox
        default-expand-all
        node-key="id"
        ref="tree"
        highlight-current
        :props="defaultProps">
      </el-tree>
  <div slot="footer" class="dialog-footer">
    <el-button @click="dialogFormVisible = false">取 消</el-button>
    <el-button type="primary" @click="getCheckedKeys">确 定</el-button>
  <el-button @click="getCheckedKeys">通过 key 获取</el-button>
  </div>
</el-dialog>
</el-card>

  
   
</template>

<script>
import {getRole} from '../api/common'
import {addRole} from '../api/common'
import {updaterole} from '../api/common'



  export default {
    mounted () {
      this.getlist()
    },
     methods: {
      getCheckedKeys() {
        this.dialogFormVisible = false
        console.log(this.$refs.tree.getCheckedKeys());
        this.updas.menus=this.$refs.tree.getCheckedKeys(),
        console.log(this.updas)
          updaterole(this.updas).then((res)=>{
            console.log(res)
            if(res.data.status==0){
                    this.$message({
                      type: 'success',
                      message: '权限修改成功！'
                    });
                    this.getlist();
                  }else{
                    this.$message({
                      type: 'error',
                      message: res.data.msg+'!'
                    });
                  }
          })
      },
      handleCurrentChange(val) {
        this.obj.pageNum=val;
        this.getlist()
      },
       getlist(){
            getRole(this.obj).then((res)=>{
            this.tableData=res.data.data.list
            this.total=res.data.data.total;
          })
       },
      tableRowClassName({rowIndex}) {
        if (rowIndex%2 != 0) {
          return 'warning-row';
        }
        return '';
      },
      handleEdit(row){
        console.log(row);
        this.dialogFormVisible = true
        this.updas._id=row._id,
        this.updas.auth_time=+new Date(),
        this.updas.auth_name='admin'
      },
      open() {
        this.$prompt('请输入角色名', '添加角色', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
        }).then(({ value }) => {
          if(value){
            this.$message({
              type: 'success',
              message: '角色添加成功: ' + value
            });
            addRole({roleName:value}).then((res)=>{
                console.log(res)
                this.getlist()
            })
          }else{
            this.$message({
              type: 'error',
              message: '角色添加失败 ！'
            });
          }
        });
      },
      timestampToTime(timestamp) {
        let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        let Y = date.getFullYear() + '-';
        let M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
        let D = date.getDate() + ' ';
        let h = date.getHours() + ':';
        let m = date.getMinutes() + ':';
        let s = date.getSeconds();
        let w = '上午';
        if(date.getHours()>=12){
            w='下午'
        }else{
            w='上午'
        }
        
        return Y+M+D+w+h+m+s;
      },
    },
    data() {
      return {
        updas:{
          _id:'',
          menus:[],
          auth_time:[],
          auth_name:''
        },
        obj:{
          pageNum:1,
          pageSize:5
        },
        total:5,
        tableData: [],
        dialogFormVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px',
        data: [{
          id: '/home',
          label: '首页'
        }, {
          id: '/goods',
          label: '商品',
          children: [{
            id: '/category',
            label: '品类管理'
          }, {
            id: '/product',
            label: '商品管理'
          }]
        }, {
          id: '/users',
          label: '用户',
          children: [{
            id: '/user',
            label: '用户管理'
          }, {
            id: '/role',
            label: '权限管理'
          }]
        },{
          id: '/orders',
          label: '订单',
          children: [{
            id: '/order',
            label: '订单管理',
          }]
        }],
        defaultProps: {
          children: 'children',
          label: 'label'
        }
      }
    }
  }
</script>
<style>
  .el-table .warning-row {
    background: #fafafa;
  }

  .el-table .success-row {
    background: #f0f9eb;
  }
  .clearfix{
    height: 40px;
  }
  .el-pagination{
    height: 30px;
    margin-top: 20px;
  }
  .el-pagination{
          text-align: center;
      }
</style>