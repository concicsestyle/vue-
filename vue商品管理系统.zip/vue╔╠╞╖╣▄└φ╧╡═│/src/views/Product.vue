<template>

<el-card class="box-card">
  <div slot="header" class="clearfix">
  
    <span class="search"> 
      <el-select v-model="region" style="width:150px" placeholder="搜索规则">
        <el-option label="按照名字搜索" value="1"></el-option>
        <el-option label="按照描述搜索" value="0"></el-option>
      </el-select>
      <el-input v-model="input" style="width:150px" placeholder="请输入关键字"></el-input>
      <el-button  @click="search" type="primary"  icon="el-icon-search">搜索</el-button>
    </span>

    <el-button style="float:right;" @click="addpuo" type="primary"  icon="el-icon-plus">添加商品</el-button>
  </div>
  <el-table
    :data="tableData"
    :row-class-name="tableRowClassName"
    border
    style="width: 100%">
    <el-table-column
      prop="name"
      label="商品名称">
    </el-table-column>
    <el-table-column
      prop="desc"
      label="商品描述">
    </el-table-column>
    <el-table-column
      prop="price"
      label="商品价格">
    </el-table-column>
    <el-table-column
      label="商品状态">
      <template slot-scope="scope">
        <el-button
          size="mini"
          v-if='scope.row.status!=1'
          @click="Status(scope.row,1)">上架</el-button>

        <el-button
          size="mini"
          v-else
          @click="Status(scope.row,0)">下架</el-button>

          <el-button
          type="text"
          size="mini"
          v-if='scope.row.status==1'>销售中</el-button>
          <el-button
          type="text"
          v-else
          size="mini">已下架</el-button>
      </template>
    </el-table-column>
    <el-table-column
      label="操作选项">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="spxq(scope.row)">详情</el-button>
          <el-button
          size="mini"
          @click="handleEdit(scope.row)">修改</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-pagination
    background
    @current-change="handleCurrentChange"
    layout="prev, pager, next"
    :page-size='obj.pageSize'
    :total="total">
  </el-pagination>
</el-card>

  
   
</template>

<script>
import {getproductlist} from '../api/common'
import {updateStatus} from '../api/common'
import {searchsp} from '../api/common'


  export default {
    mounted () {
      this.getlist()
    },
    
     methods: {
       spxq(row){
      console.log(row)
      this.$router.push({path:'productdata',query:{
              categoryId:row.categoryId,
              name:row.name,
              desc:row.desc,
              price:row.price,
              imgs:row.imgs,
              detail:row.detail
      }})
    },
       handleCurrentChange(val) {
        this.obj.pageNum=val;
        this.getlist()
      },
      getsearchsp(obj){
          searchsp(obj).then((res)=>{
              console.log(res.data.data)
              this.tableData=res.data.data.list
              this.total=res.data.data.total;
            })
      },
       Status(row,val){
         updateStatus({productId:row._id,status:val}).then((res)=>{
              console.log(res)
              this.getlist()
            })
       },
       addpuo(){
         this.$router.push({path:'productadd'})
       },
       getlist(){
            getproductlist(this.obj).then((res)=>{
              console.log(res.data.data)
              this.tableData=res.data.data.list
              this.total=res.data.data.total;
            })
       },
       search(){
        //  console.log(this.forms);
         console.log(this.input,this.region);
         if(this.region==1){
           this.forms={
              pageNum:1,
              pageSize:4,
              productName:this.input,
              }
              this.getsearchsp(this.forms)
         }else{
           this.forms={
              pageNum:1,
              pageSize:4,
              productDesc:this.input,
              }
           this.getsearchsp(this.forms)
         }
        //  
       },
      tableRowClassName({rowIndex}) {
        if (rowIndex%2 != 0) {
          return 'warning-row';
        }
        return '';
      },
      handleEdit(row){
        console.log(row);
        this.$router.push({path:'productup',query:row})
      },
    },
    data() {
      return {
        forms:{
        },
        region:'',
          input:'',
        total:4,
        obj:{
          pageNum:1,
          pageSize:4
        },
        tableData: [],
        dialogFormVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px'
      }
    }
  }
</script>
<style>
  .el-table .warning-row {
    background: #fafafa;
  }

  .el-table .success-row {
    background: #f0f9eb;
  }
  .clearfix{
    height: 40px;
  }
  .el-pagination{
    height: 30px;
    margin-top: 20px;
  }
  .search{
    display: inline-flex;
    width: 430px;
    justify-content: space-between;
  }
  .el-pagination{
          text-align: center;
      }
</style>