<template>
  <div class='home'>
    <el-container>
      <el-aside width="220px">
        <div class="loginbox">商品管理系统</div>
        <el-row class="tac">
          <el-col>
            <el-menu
            style="border: 0px;"
              default-active="1"
              class="el-menu-vertical-demo"
              @open="handleOpen"
              @close="handleClose"
              background-color="#3e4e5e"
              text-color="#fff"
              active-text-color="#ffd04b">
              <el-menu-item index="1" @click="echartss()">
                <i class="el-icon-menu"></i>
                <span slot="title">首页</span>
              </el-menu-item>
              <el-submenu index="2">
                <template slot="title">
                  <i class="el-icon-s-shop"></i>
                  <span>商品</span>
                </template>
                <el-menu-item-group>
                  <el-menu-item index="2-1" @click="categorys()"> <i class="el-icon-s-marketing"></i>品类管理</el-menu-item>
                  <el-menu-item index="2-2" @click="products()"><i class="el-icon-shopping-bag-1"></i>商品管理</el-menu-item>
                </el-menu-item-group>
              </el-submenu>
              <el-submenu index="3">
                <template slot="title">
                  <i class="el-icon-user-solid"></i>
                  <span>用户</span>
                </template>
                <el-menu-item-group>
                  <el-menu-item index="3-1" @click="users()"><i class="el-icon-user"></i>用户管理</el-menu-item>
                  <el-menu-item index="3-2" @click="roles()"><i class="el-icon-setting"></i>权限管理</el-menu-item>
                </el-menu-item-group>
              </el-submenu>
              <el-submenu index="4">
                <template slot="title">
                  <i class="el-icon-eleme"></i>
                  <span>订单</span>
                </template>
                <el-menu-item-group>
                  <el-menu-item index="4-1"  @click="orders()"><i class="el-icon-phone-outline"></i>订单管理</el-menu-item>
                </el-menu-item-group>
              </el-submenu>
            </el-menu>
          </el-col>
        </el-row>
      </el-aside>
      <el-container>
        <el-header>
           <template>
            <div class="demo-type">
              <div>
                <el-avatar src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"></el-avatar>
              </div>
              
              <span class="username">{{this.username}}</span>
              <div>
              <el-button type="text">退出登录</el-button>
              </div>
            </div>
          </template>
        </el-header>
        <el-main>
          <router-view/>
        </el-main>
        <el-footer>Footer</el-footer>
      </el-container>
    </el-container>
  </div>
</template>

<script>

export default {
    data(){
       return {
         username:'admin',
       }
    },
   methods: {
     
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      },
      users(){
        this.$router.push({path:'user'})
      },
      roles(){
        this.$router.push({path:'role'})
      },
      categorys(){
        this.$router.push({path:'category'})
      },
      echartss(){
        this.$router.push({path:'echarts'})
      },
      products(){
        this.$router.push({path:'product'})
      },
      orders(){
        this.$router.push({path:'order'})
      }
    }
}
</script>
<style>
.demo-type{
  float:right;
    width: 180px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.demo-type .username{
  font-size: 14px;
}
.home{
  height: 100%;
}
.el-container{
  height: 100%;
}
  .el-header, .el-footer {
    background-color: white;
    color: #333;
  }
  
  .el-aside {
    background-color: #3e4e5e;
    color: #333;
  }
  .el-main {
    background-color: #f3f3f3;
    color: #333;
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
  .loginbox{
    text-align: center;
    line-height: 60px;
    color: white;
    font-size: 18px;
    letter-spacing:8px;
    
    width: 100%;
    height: 60px;
    background-color: cadetblue;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
</style>
