<template>
<el-card class="box-card">
  <div slot="header" class="clearfix dd">
      <el-button style="font-size:30px;" @click="tzhq" type="text" icon='el-icon-back'></el-button>
    <span class="spxqbq">商品详情</span>
  </div>
  <div class="xqhh">
    
     <br/><el-tag>商品名称</el-tag> <span>{{this.name}}</span><br/><br/>
     <el-divider><i class="el-icon-c-scale-to-original"></i></el-divider>
     <br/><el-tag>商品描述</el-tag> <span>{{this.desc}}</span><br/><br/>
     <el-divider><i class="el-icon-date"></i></el-divider>
     <br/><el-tag>商品价格</el-tag> <span>{{this.price}}</span><br/><br/>
     <el-divider><i class="el-icon-shopping-cart-full"></i></el-divider>
     <br/><el-tag>所属分类</el-tag> <span>{{this.names}}</span><br/><br/>
     <el-divider><i class="el-icon-star-off"></i></el-divider>
     <br/><div class='spxqimg'>
     <el-tag>商品图片</el-tag> <span  v-for="e in this.imgs" :key='e'> <img :src="e"></span><br/><br/>
     </div>
     <el-divider><i class="el-icon-picture-outline"></i></el-divider>
     <br/><div style="display:flex;align-items:center">
     <el-tag>商品详情</el-tag> <span v-html="this.detail"></span><br/><br/>
     </div>
     <el-divider><i class="el-icon-tickets"></i></el-divider>

     

  </div>
</el-card>
</template>
<script>
import {getCatein} from '../api/common'

  export default {
      mounted () {
              this.categoryId=this.$route.query.categoryId,
              this.name=this.$route.query.name,
              this.desc=this.$route.query.desc,
              this.price=this.$route.query.price,
              this.imgs=this.$route.query.imgs,
               this.detail=this.$route.query.detail
      this.getlist()
    },
     methods: {
        getlist(){
             getCatein({categoryId:this.categoryId}).then((res)=>{
              this.names=res.data.data.name
            })
        },
        tzhq(){
          this.$router.push({path:'product'})
        }
     },
      data(){
          return {
              categoryId:'5dd33c366fc928048407ee0e',
              name:'',
              desc:'',
              price:'',
              imgs:[],
              names:'',
              detail:''
          }
      }
  }

</script>
<style>
  .el-table .warning-row {
    background: #fafafa;
  }

  .el-table .success-row {
    background: #f0f9eb;
  }
  .clearfix{
    height: 40px;
  }
  .spxqimg{
display:flex;
align-items:center;

  }
  .spxqimg img{
    width: 150px;
  }
  .dd{
      display: flex;
      align-items: center;
  }
  .xqhh span{
    margin-left: 20px;
  }
  .el-pagination{
    height: 30px;
    margin-top: 20px;
  }
  .el-pagination{
          text-align: center;
      }
      .spxqbq{
          font-size:20px;
          margin-left: 10px;
      }
</style>