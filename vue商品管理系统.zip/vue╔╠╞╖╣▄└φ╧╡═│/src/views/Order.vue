<template>

<el-card class="box-card">
  <div slot="header" class="clearfix">
    <span class="search"> 
      <el-select v-model="ssex.region" style="width:150px" placeholder="搜索规则">
        <el-option label="按照名字搜索" value="shanghai"></el-option>
        <el-option label="按照描述搜索" value="beijing"></el-option>
      </el-select>
      <el-input v-model="ssex.input" style="width:150px" placeholder="请输入关键字"></el-input>
      <el-button  @click="search" type="primary"  icon="el-icon-search">搜索</el-button>
    </span>
  </div>
  <el-table
    :data="tableData"
    :row-class-name="tableRowClassName"
    border
    style="width: 100%">
    <el-table-column
      prop="orderId"
      label="订单号">
    </el-table-column>
    <el-table-column
      prop="recipient"
      label="收件人">
    </el-table-column>
    <el-table-column
      prop="status"
      label="订单状态">
        <template slot-scope="scope">
          <span v-if='scope.row.status'>未支付</span>
          <span v-else>已支付</span>

        </template>
    </el-table-column>
    <el-table-column
    prop='allPrice'
      label="订单总价">
    </el-table-column>
    <el-table-column
      label="创建时间">
               <template slot-scope="scope">
        <span>{{timestampToTime(scope.row.create_time)}}</span>
      </template>
    </el-table-column>
    <el-table-column
      label="操作选项">
      <template slot-scope="scope">
        <el-button
        type='text'
          size="mini"
          @click="handleEdit(scope.$index, scope.row)">查看详情</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-pagination
    background
    @current-change="handleCurrentChange"
    layout="prev, pager, next"
    :page-size='obj.pageSize'
    :total="total">
  </el-pagination>
</el-card>

  
   
</template>

<script>
//  import {orderinfo} from '../api/common'
 import {orderlist} from '../api/common'
 import {ordersearch} from '../api/common'


  export default {
    mounted () {
      this.getlist()
    },
    
     methods: {
       getsearch(){
            ordersearch(this.obj).then((res)=>{
              console.log(res.data.data)
              this.tableData=res.data.data.list
              this.total=res.data.data.total;
            })
       },
        getlist(){
            orderlist(this.obj).then((res)=>{
              console.log(res.data.data)
              this.tableData=res.data.data.list
              this.total=res.data.data.total;
            })
       },
       search(){
         console.log(this.ssex);
       },
      tableRowClassName({rowIndex}) {
        if (rowIndex%2 != 0) {
          return 'warning-row';
        }
        return '';
      },
      handleEdit(index,row){
        console.log(index,row);
        this.dialogFormVisible = true
      },
      handleCurrentChange(val) {
        this.obj.pageNum=val;
        this.getlist()
      },
      timestampToTime(timestamp) {
        let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        let Y = date.getFullYear() + '-';
        let M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
        let D = date.getDate() + ' ';
        let h = date.getHours() + ':';
        let m = date.getMinutes() + ':';
        let s = date.getSeconds();
        let w = '上午';
        if(date.getHours()>=12){
            w='下午'
        }else{
            w='上午'
        }
        
        return Y+M+D+w+h+m+s;
      },
    },
    data() {
      return {
        obj:{
          pageNum:1,
          pageSize:4
        },
        total:4,
        ssex:{
          input:'',
          region: '',
        },
        tableData: [{
          date: '2016',
          name: '王小虎'
        }, {
          date: '2016',
          name: '王小虎'
        }, {
          date: '2016',
          name: '王小虎'
        }, {
          date: '2016',
          name: '王小虎'
        }],
        dialogFormVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px'
      }
    }
  }
</script>
<style>
  .el-table .warning-row {
    background: #fafafa;
  }

  .el-table .success-row {
    background: #f0f9eb;
  }
  .clearfix{
    height: 40px;
  }
  .el-pagination{
    height: 30px;
    margin-top: 20px;
  }
  .search{
    display: inline-flex;
    width: 430px;
    justify-content: space-between;
  }
  .el-pagination{
          text-align: center;
      }
</style>