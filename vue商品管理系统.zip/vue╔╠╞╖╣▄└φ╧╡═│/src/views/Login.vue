<template>
<div class="digs">
    
  <div class="boxss">
    <el-container class="l-contain">
           <div class="form-box">
             <h1>用户登录</h1>
            <el-form status-icon :model="form" :rules="rules" ref="loginForm">
                <el-form-item prop="username">
                    <el-input  placeholder="输入用户名" prefix-icon="el-icon-user" v-model="form.username"></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input placeholder="密码" type="password"  prefix-icon="el-icon-lock" v-model="form.password"></el-input>
                </el-form-item>
                <el-form-item>
                 <el-button type="primary" @click="onSubmit('loginForm')">登录</el-button>
                </el-form-item>
            </el-form>
           </div>
       

        </el-container>
  </div>
  
</div>
</template>

<script>
 import {login} from '../api/common'

export default {
    
     data(){
        return {
            form:{
              username:"",
              password:""
           },
           rules:{
               username:[{ required: true, message: '用户名不能为空', trigger: 'blur' },
                         { min: 5, max: 12, message: '长度在 5 到 12 个字符', trigger: 'blur' }],
               password:[
                         { required: true, message: '密码不能为空', trigger: 'change' },
                         { min: 5, max: 12, message: '长度在 5 到 12 个字符', trigger: 'change' }

               ]
           }
        }

    },
     methods: {
        onSubmit(loginForm){
            // console.log(this.form)
           this.$refs[loginForm].validate((valid) => {
               if (valid) {
                   login(this.form).then((res)=>{
                        // console.log(res)
                        if(res.data.status==0){
                            this.$router.push({path:'/home'})
                                this.$message({
                                    type: 'success',
                                    message: '登录成功！'
                                });
                                }else{
                                this.$message({
                                    type: 'error',
                                    message: res.data.msg+'!'
                                });
                                }
                    })
                } else {
                    this.$message('表单输入错误！');
                    return false;
                }
            });
        }
    },
}
</script>
<style lang="less">
.headers{
    height: 80px;
    background-color: rgba(255,255,255,0.5)
}
.digs{
    width: 100%;
    height: 100%;
    background-color: rgb(138, 192, 171);
}
.digs>.boxss{
    width: 450px;
    height: 390px;
    border-radius: 5px;
    margin: 0 auto;
    position: relative;
    top: 50%;
    transform: translate(0,-50%);
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    background-color: rgba(255,255,255,0.5)
}
.l-contain{
        height: 100%;
    }
    .form-box{
        width: 400px;
        margin: 0 auto;
        padding: 20px 40px;
            box-sizing: border-box;
            
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    }
      .form-box button{
          width: 100%
      }
      #app{
          width: 100%;
          height: 100%;
      }
      *{
          margin: 0;
          padding: 0;
      }
      html,body{
          width: 100%;
          height: 100%;
      }
      
</style>
