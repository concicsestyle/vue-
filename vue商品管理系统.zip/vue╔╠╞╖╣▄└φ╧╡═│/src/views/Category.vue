<template>

<el-card class="box-card">
  <div slot="header" class="clearfix">
    <el-button @click="dhl" type="text">一级商品分类列表</el-button>{{msgg}}
    <el-button style="float:right;" type="primary"  @click="addscl">添加分类</el-button>
  </div>
  
  <el-table
    :data="tableData"
    :row-class-name="tableRowClassName"
    border
    style="width: 100%">
    <el-table-column
      prop="name"
      label="商品分类">
    </el-table-column>
    <el-table-column
      label="操作选项">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="open(scope.row)">修改分类</el-button>
        <el-button
          size="mini"
          v-if="boos" 
          @click="handleEdit(scope.row)">查看子分类</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-pagination
    background
    @current-change="handleCurrentChange"
    layout="prev, pager, next"
    :page-size='obj.pageSize'
    :total="total">
  </el-pagination>
  <el-dialog style="float:left" title="添加分类" :visible.sync="dialogFormVisible">
  <el-form :model="form">
    <el-form-item label="分类列表" :label-width="formLabelWidth">
      <el-select v-model="form.parentId" value='shanghai'>
        <el-option label="一级分类" v-if="boos" value="0"></el-option>
        <el-option label="二级分类" v-else :value="parentId"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="分类名称" :label-width="formLabelWidth">
      <el-input v-model="form.categoryName" autocomplete="off"></el-input>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="dialogFormVisible = false">取 消</el-button>
    <el-button type="primary" @click="fltijiao">确 定</el-button>
  </div>
</el-dialog>
</el-card>



  
   
</template>

<script>
import {getCategory} from '../api/common'
import {updateCategory} from '../api/common'
import {addCategory} from '../api/common'
// import {getCatein} from '../api/common'



  export default {
    
    data() {
      return {
        msgg:'',
        boos:true,
        tableData: [],
        dialogFormVisible: false,
        form: {
          parentId: '',
          categoryName: ''
        },
        formLabelWidth: '120px',
        total:1,
        obj:{
          parentId:'0',
          pageNum:1,
          pageSize:5
        },
        updatafl:{
          categoryId:'',
          categoryName:''
        },
        parentId:'',
      }
    },
    mounted () {
      this.getlist()
    },
     methods: {
       addscl(){
         this.dialogFormVisible = true
          // this.boos= false
       },
      handleCurrentChange(val) {
        this.obj.pageNum=val;
        this.getlist()
      },
      dhl(){
        this.boos= true
        this.obj.parentId='0';
         this.msgg=''
        this.getlist()
      },
       getlist(){
         getCategory(this.obj).then((res)=>{
        // console.log(res.data.data)
        this.tableData=res.data.data.list
        this.total=res.data.data.total;
      })
       },
      tableRowClassName({rowIndex}){
        if (rowIndex%2 != 0) {
          return 'warning-row';
        }
        return '';
      },
      handleEdit(row){
        this.parentId=row._id+''
        this.msgg='->'+row.name
        this.obj.parentId=row._id+''
        this.getlist()
        console.log(row)
        this.boos= false
      },
      fltijiao(){
        console.log(this.form)
            this.dialogFormVisible = false
              addCategory(this.form).then((res)=>{
                  console.log(res.data)
                  this.getlist()
                  if(res.data.status==0){
                    this.$message({
                      type: 'success',
                      message: '品类添加成功！'
                    });
                    this.getlist();
                  }else{
                    this.$message({
                      type: 'error',
                      message: res.data.msg+'!'
                    });
                  }
            })
        
      },
      updatafls(obj){
          updateCategory(obj).then((res)=>{
          console.log(res)
          this.getlist()
      })
      },
      open(row) {
        console.log(row._id)
        this.$prompt('请输入新分类名', '修改分类', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
        }).then(({ value }) => {
          if(value){
            this.updatafl.categoryId=row._id
            this.updatafl.categoryName=value
            this.updatafls(this.updatafl)
            this.$message({
              type: 'success',
              message: '分类修改成功: ' + value
            });
          }else{
            this.$message({
              type: 'error',
              message: '分类修改失败 ！'
            })
          }
        }).catch(() => {
              // this.$message({
              //   type: 'info',
              //   message: '取消输入'
              // });       
        });
      }
    }
  }
</script>
<style>
  .el-table .warning-row {
    background: #fafafa;
  }

  .el-table .success-row {
    background: #f0f9eb;
  }
  .clearfix{
    height: 40px;
    line-height: 40px;
  }
  .el-pagination{
    height: 30px;
    margin-top: 20px;
  }
  .el-pagination{
          text-align: center;
      }
</style>