<template>

<el-card class="box-card">
  <div slot="header" class="clearfix">
    <el-button style="float:left;" type="primary"  @click="cjyh">创建用户</el-button>
  </div>
  
  <el-table
    :data="userData"
    :row-class-name="tableRowClassName"
    border
    style="width: 100%">
    <el-table-column
      prop="username"
      label="用户名">
    </el-table-column>
    <el-table-column
      prop="email"
      label="邮箱">
    </el-table-column>
    <el-table-column
      prop="phone"
      label="电话">
    </el-table-column>
    <el-table-column
      label="注册时间">
      <template slot-scope="scope">
        <span>{{timestampToTime(scope.row.create_time)}}</span>
      </template>
    </el-table-column>
    <el-table-column
      prop="rolename"
      label="权限角色">
    </el-table-column>
    <el-table-column
      label="操作">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="xiugai(scope.row)">修改</el-button>
          <el-button
          size="mini"
          @click="dels(scope.row._id)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-pagination
    background
    @current-change="handleCurrentChange"
    layout="prev, pager, next"
    :page-size='obj.pageSize'
    :total="total">
  </el-pagination>
  <el-dialog style="float:left" title="收货地址" :visible.sync="dialogFormVisible">
  <el-form :model="form" :rules="rules" ref="loginForm">
    <el-form-item label="用户名" prop='username' :label-width="formLabelWidth">
      <el-input v-model="form.username"  autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="密码" v-if="this.boots" prop='password'  :label-width="formLabelWidth">
      <el-input v-model="form.password" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="手机号" prop='phone'  :label-width="formLabelWidth">
      <el-input v-model="form.phone" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="邮箱"  prop='email' :label-width="formLabelWidth">
      <el-input v-model="form.email" autocomplete="off"></el-input>
    </el-form-item>
    <el-form-item label="角色" prop='role_id' :label-width="formLabelWidth">
      <el-select v-model="form.role_id" placeholder="请选择用户权限角色">
        <el-option
              v-for="item in roless"
              :key="item._id"
              :label="item.name"
              :value="item._id">
        </el-option>
      </el-select>
    </el-form-item>
  </el-form>
  <div slot="footer" class="dialog-footer">
    <el-button @click="qx">取 消</el-button>
    <el-button type="primary" @click="onSubmit('loginForm')">确 定</el-button>
  </div>
</el-dialog>
</el-card>


</template>

<script>
import {getUserList} from '../api/common'
import {deleteUser} from '../api/common'
import {addUser} from '../api/common'
import {updateUser} from '../api/common'


  export default {
    mounted () {
      this.updatas();
    },
     methods: {
       onSubmit(loginForm){
           this.$refs[loginForm].validate((valid) => {
               if (valid) {
                   this.adds()
                } else {
                    this.$message('表单输入错误！');
                    return false;
                }
            });
        },
       adds(){
         if(this.boots){
           this.dialogFormVisible = false
                addUser(this.form).then((res)=>{
                  if(res.data.status==0){
                  this.$message({
                    type: 'success',
                    message: '用户添加成功！'
                  });
                  this.qx()
                  this.updatas();
                }else{
                  this.$message({
                    type: 'error',
                    message: res.data.msg+'!'
                  });
                }
              })
          }else{
            updateUser(this.form).then((res)=>{
              if(res.data.status==0){
                  this.$message({
                    type: 'success',
                    message: '用户修改成功！'
                  });
                  this.qx()
                  this.updatas();
                }else{
                  this.$message({
                    type: 'error',
                    message: res.data.msg+'!'
                  });
                }
            })
          }
          
       },
       qx(){
         this.dialogFormVisible = false
         this.form.username= '';
         this.form.password= '';
         this.form.email= '';
         this.form.phone= '';
         this.form.role_id= '';
       },
      handleCurrentChange(val) {
        this.obj.pageNum=val;
        this.updatas()
      },
       updatas(){
          getUserList(this.obj).then((res)=>{
            this.userData=res.data.data.list
            this.roless=res.data.data.roles
            this.total=res.data.data.total;
            this.userData=this.userData.map((item)=>{
              this.role=res.data.data.roles.find((items)=>{
                return items._id==item.role_id;
              })
              item.rolename=this.role.name
              return item
            })
          })
      },
       dels(userId){
         deleteUser({userId:userId}).then((res)=>{
            this.updatas();
          console.log(res.statusText);
        if(res.statusText=='OK'){
            this.$message({
              type: 'success',
              message: '用户删除成功！'
            });
          }else{
            this.$message({
              type: 'error',
              message: '用户删除失败 ！'
            });
          }
          })
       },
      tableRowClassName({rowIndex}){
        if (rowIndex%2 != 0) {
          return 'warning-row';
        }
        return '';
      },
      xiugai(rows){
        this.boots=false;
        this.dialogFormVisible = true
         this.form.username= rows.username;
         this.form.email= rows.email;
         this.form.phone= rows.phone;
         this.form.role_id= rows.role_id;
        this.form._id=rows._id
      },

      cjyh(){
        this.qx()
        this.boots=true;
        this.dialogFormVisible = true
      },
      timestampToTime(timestamp) {
        let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        let Y = date.getFullYear() + '-';
        let M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
        let D = date.getDate() + ' ';
        let h = date.getHours() + ':';
        let m = date.getMinutes() + ':';
        let s = date.getSeconds();
        let w = '上午';
        if(date.getHours()>=12){
            w='下午'
        }else{
            w='上午'
        }
        
        return Y+M+D+w+h+m+s;
      },
    },
    data() {
      return {
        boots:true,
        rules:{
               username:[{ required: true, message: '用户名不能为空', trigger: 'blur' },
                         { min: 2, max: 12, message: '长度在 2 到 12 个字符', trigger: 'blur' }],
               password:[
                         { required: true, message: '密码不能为空', trigger: 'blur' },
                         { min: 6, max: 12, message: '长度在 6 到 12 个字符', trigger: 'blur' }
               ],
               phone:[
                         { required: true, message: '手机号不能为空', trigger: 'blur' },
                         { len:11, message: '请输入正确的手机号',trigger: ['blur', 'change']}
               ],
               email:[
                         { required: true, message: '邮箱不能为空', trigger: 'blur' },
                         {type: 'email', message: '请输入正确的邮箱地址' ,trigger: ['blur', 'change']}
               ],
               role_id:[
                         { required: true, message: '角色不能为空', trigger: 'blur' },
               ]
        },
        total:5,
        obj:{
          pageNum :1,
          pageSize :5
        },
        userData: [],
        dialogFormVisible: false,
        form: {
          username: '',
          password: '',
          email: '',
          phone: '',
          role_id: '',
        },
        roless:[],
        role:[],
        formLabelWidth: '120px'
      }
    }
  }
</script>
<style>
  .el-table .warning-row {
    background: #fafafa;
  }

  .el-table .success-row {
    background: #f0f9eb;
  }
  .clearfix{
    height: 40px;
  }
  .el-pagination{
    height: 30px;
    margin-top: 20px;
  }
  .el-pagination{
          text-align: center;
      }
</style>