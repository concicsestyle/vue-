<template>
  <div class="echartbox">
    <el-card class="box-card">
      <div style="display:flex">
<div class="boxec">
          <el-progress :text-inside="true" :stroke-width="26" :percentage="70"></el-progress>
          <el-progress :text-inside="true" :stroke-width="24" :percentage="100" status="success"></el-progress>
          <el-progress :text-inside="true" :stroke-width="22" :percentage="80" status="warning"></el-progress>
          <el-progress :text-inside="true" :stroke-width="20" :percentage="50" status="exception"></el-progress>
      </div>
      <div class="ecss">
        <div>

        <el-progress type="circle" :percentage="50"></el-progress>
        </div>
        <div>
        <el-progress type="circle"   :percentage="75" color='slateblue'></el-progress>
        </div>
      </div>
      </div>
      
      <div id="mains" style="width: 100%;height:500px;"></div>
    </el-card>
  </div>
  
</template>

<script>
       
export default {
        name: 'FuncFormsBase',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  mounted () {
    this.drawLine();
  },
  methods: {
    drawLine () {
      var echarts = require('echarts');
      var myChart = echarts.init(document.getElementById('mains'));
      myChart.setOption({
        grid:{
          height:'40%',
          bottom:70,
        },
        legend:{
          
        },
        xAxis: {
          data: ['2015','2016', '2017', '2018',  '2018', '2019'],
        },
        yAxis: {
          min:0,
          max:100,
          splitLine:{show:true}
          },
        series: [
          {
            name: 'Access to the source',
            type: 'pie',
            width:'400px',
            height:'250px',
            center:['50%',120],
            left:'35%',
            radius: '55%',
            data:[
                {value:174, name:'Union advertising'},
                {value:310, name:'email marketing'},
                {value:85, name:'direct access'},
                {value:250, name:'Search Engine'}
            ]
        },{
          type :'line',
          data:[60,52,60,55,50,60]
        },{
          type :'line',
          data:[70,73,78,65,60,56]
        },{
          type :'line',
          data:[80,85,72,76,70,67]
        },{
          type :'line',
          data:[50,55,45,40,42,50]
        }]
      });
    }
  }
}
</script>

<style>
 .text {
    font-size: 14px;
  }
.box-card {
    width: 100%;
  }
   .text {
    font-size: 14px;
  }
  .ecss>div{
    width: 200px;
    height: 200px;
    background-color: #bc8f8f;
    border-radius: 5px;
    display: flex;
    justify-content: space-around;
    align-items: center;

  }
  .ecss>div:nth-of-type(1){
    background-color:#7fc3bf
  }
  .ecss{
    width: 50%;
    height: 240px;
    margin-bottom: 40px;
 display: flex;
    justify-content: space-around;
    align-items: center;
  }
  .boxec{
    width: 50%;
    height: 200px;
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-around
  }
</style>
