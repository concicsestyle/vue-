 <template>
<el-card class="box-card">

  <div slot="header" class="clearfix dd">
    <el-button style="font-size:30px;" @click="tzhq" type="text" icon='el-icon-back'></el-button>
    <span class="spxqbq">商品修改</span>
  </div>
  <div>
<el-form :model="form" :rules="rules" ref="loginForm"  label-width="100px" >
   <el-form-item label="商品名称" prop="name">
    <el-input v-model="form.name"></el-input>
  </el-form-item>
  <el-form-item label="商品描述" prop="desc">
    <el-input v-model="form.desc"></el-input>
  </el-form-item>
  <el-form-item label="商品价格" prop="price">
    <el-input v-model="form.price"></el-input>
  </el-form-item>
 <el-form-item label="商品分类" prop='categoryId' >
    <el-select v-model="form.categoryId" placeholder="请选择分类">
        <el-option
              v-for="item in tableData"
              :key="item._id"
              :label="item.name"
              :value="item._id">
        </el-option>
    </el-select>
  </el-form-item>
  <el-form-item label="商品图片" prop="imgs">
    <el-upload
            action="https://jsonplaceholder.typicode.com/posts/"
            list-type="picture-card"
            :on-preview="handlePictureCardPreview"
            :on-remove="handleRemove">
            <i class="el-icon-plus"></i>
            </el-upload>
            <el-dialog :visible.sync="dialogVisible">
            <img width="100%" :src="dialogImageUrl" alt="">
            </el-dialog>
  </el-form-item>
  <el-form-item label="商品详情" prop="detail">
    <el-input v-model="form.detail"></el-input>
  </el-form-item>
    
  </el-form>
  </div>
  <el-button type="primary" @click="querys('loginForm')">确认提交</el-button>
  <el-button @click="cz">重置</el-button>
</el-card>
 </template>


 <script>
 import {getCategory} from '../api/common'
 import {productup} from '../api/common'

 export default {
     mounted () {

        // console.log(this.$route.query)
         this.form=this.$route.query
      this.getlist()
    },
    methods:{
        querys(loginForm){
            // console.log(this.form)
           this.$refs[loginForm].validate((valid) => {
               if (valid) {
                   productup(this.form).then((res)=>{
                        // console.log(res)
                        if(res.data.status==0){
                                this.$message({
                                    type: 'success',
                                    message: '商品修改成功！'
                                });
                                }else{
                                this.$message({
                                    type: 'error',
                                    message: res.data.msg+'!'
                                });
                                }
                    })
                } else {
                    this.$message('表单输入错误！');
                    return false;
                }
            });
        },
         tzhq(){
          this.$router.push({path:'product'})
        },
        getlist(){
         getCategory(this.obj).then((res)=>{
            // console.log(res.data.data)
            this.tableData=res.data.data.list
         })
        },
        handleRemove(file, fileList) {
            console.log(file, fileList);
        },
        handlePictureCardPreview(file) {
            this.dialogImageUrl = file.url;
            this.dialogVisible = true;
        },
        cz(){
                this.form.categoryId='',
                this.form.name='',
                this.form.desc='',
                this.form.price ='',
                this.form.detail ='',
                this.form.imgs=''
        }
    },
    data(){
        return{
            dialogImageUrl: '',
            dialogVisible: false,
            form: {
                categoryId:'',
                pCategoryId :'0',
                name    :'',
                desc    :'',
                price :'',
                detail :'',
                imgs:'',
            },
            ruleForm:{

            },
            rules:{
                    categoryId:[{ required: true, message: '不能为空', trigger: 'blur' }],
                    pCategoryId :[{ required: true, message: '不能为空', trigger: 'blur' }],
                    name    :[{ required: true, message: '不能为空', trigger: 'blur' }],
                    desc    :[{ required: true, message: '不能为空', trigger: 'blur' }],
                    price :[{ required: true, message: '不能为空', trigger: 'blur' }],
                    detail :[{ required: true, message: '不能为空', trigger: 'blur' }],
            },
            tableData:[],
            obj:{
                parentId:'0',
                ageNum:1,
                pageSize:10
            }
        }
    }
 }
 </script>
<style>
.dd{
      display: flex;
      align-items: center;
  }
.spxqbq{
          font-size:20px;
          margin-left: 10px;
      }
</style>