import server from '../utils/request.js';

export function getCategory(obj){//获取分类列表
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/category/list',
        params:obj
    })
}
export function getUserList(obj){//获取用户列表
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/user/list',
        params:obj
    })
}
export function deleteUser(obj){//删除用户
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/user/delete',
        data:obj
    })
}

export function addUser(obj){//添加用户
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/user/add',
        data:obj
    })
}
export function updateUser(obj){//更新用户
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/user/update',
        data:obj
    })
}
export function updateCategory(obj){//更新品类名称
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/category/update',
        data:obj
    })
}
export function addCategory(obj){//添加品类名称
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/category/add',
        data:obj
    })
}
export function getCatein(obj){//根据商品id获取分类列表
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/category/info',
        params:obj
    })
}
export function getRole(obj){//获取角色列表
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/role/list',
        params:obj
    })
}
export function addRole(obj){//添加角色
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/role/add',
        data:obj
    })
}

export function getproductlist(obj){//获取商品列表
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/product/list',
        params:obj
    })
}
export function updateStatus(obj){//商品上下架
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/product/updateStatus',
        data:obj
    })
}
export function searchsp(obj){//搜索商品
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/product/search',
        params:obj
    })
}
export function updaterole(obj){//角色权限修改
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/role/update',
        data:obj
    })
}

export function productadd(obj){//商品添加
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/product/add',
        data:obj
    })
}
export function productup(obj){//商品修改
    return server({//返回来一个promise
        method:'post',
        url:'/api/manage/product/update',
        data:obj
    })
}
export function login(obj){//登录
    return server({//返回来一个promise
        method:'post',
        url:'/api/login',
        data:obj
    })
}
export function orderlist(obj){//订单列表
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/order/list',
        params:obj
    })
}
export function orderinfo(obj){//订单详情
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/order/info',
        params:obj
    })
}
export function ordersearch(obj){//订单搜索
    return server({//返回来一个promise
        method:'get',
        url:'/api/manage/order/search',
        params:obj
    })
}

// export function getFours(){
//     return server({
//         method:'post',
//         url:'/api/getfours',
//         data:{
            
//         }
//     })
// }