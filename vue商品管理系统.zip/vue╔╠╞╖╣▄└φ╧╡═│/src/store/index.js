import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
  },
  mutations: {
  },
  actions: {//做异步操作的，操作成功后提交mutations
  },
  modules: {

  }
})
