<template>
  <div id="app">
      <!-- <router-link to="/login">login</router-link> -->
    <router-view/>
  </div>
</template>

<script>

export default {
  
}
</script>

<style lang="less">

</style>
